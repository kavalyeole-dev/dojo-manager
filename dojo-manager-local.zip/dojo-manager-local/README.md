# Dojo Manager — run on your laptop

## 1. Install Node.js (one-time)
Download and install the LTS version from https://nodejs.org — this gives you `node` and `npm`.
Check it worked by opening a terminal and running:
```
node -v
npm -v
```

## 2. Install the project's dependencies
Open a terminal, go into this folder, then run:
```
cd dojo-manager-local
npm install
```

## 3. Run it
```
npm run dev
```
Terminal will print a local address, usually `http://localhost:5173`. Open that in your browser — the app is now running.

Your data (students, attendance, payments) saves in that browser's storage, on this laptop. It'll still be there next time you open the app, as long as you use the same browser and don't clear its site data.

## Stopping / restarting
- Press `Ctrl+C` in the terminal to stop the server.
- Run `npm run dev` again any time to bring it back up.

## Optional: a version you can double-click without a terminal
Once you're happy with it, run:
```
npm run build
```
This creates a `dist` folder with a fully built version. You'd still need a simple local server to open it from a browser (double-clicking the HTML file directly won't load the app correctly) — ask if you want help with that step.

## Notes
- This is a single-laptop, single-browser tool — data doesn't sync across devices.
- If you ever want it accessible from your phone too, or shared with an assistant teacher, that needs a small backend/database — a bigger step, happy to help when you're ready.
