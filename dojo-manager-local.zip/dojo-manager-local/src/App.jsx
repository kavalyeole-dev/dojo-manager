import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  Users, CalendarCheck, Wallet, FileText, Search, Plus, Check, X,
  Printer, Trash2, Pencil, ChevronLeft, ChevronRight, ShieldCheck,
  Phone, RotateCcw, AlertCircle
} from "lucide-react";
import logo from "./assets/logo.jpg";

/* ---------------------------------------------------------------
   DOJO MANAGER — single-teacher karate class administration tool
   Data persists via window.storage (personal, per-user, per-device)
----------------------------------------------------------------*/

const BELTS = [
  { name: "White", color: "#F1EAD9", text: "#1C1B1A" },
  { name: "Yellow", color: "#D9B23C", text: "#1C1B1A" },
  { name: "Orange", color: "#C6702B", text: "#F1EAD9" },
  { name: "Green", color: "#3E6B4A", text: "#F1EAD9" },
  { name: "Blue", color: "#2E5478", text: "#F1EAD9" },
  { name: "Brown", color: "#5A3A25", text: "#F1EAD9" },
  { name: "Black", color: "#1C1B1A", text: "#D9B23C" },
];

const METHODS = ["Cash", "UPI", "Card", "Bank Transfer"];

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}
function monthKey(d) {
  return d.slice(0, 7);
}
function monthLabel(mk) {
  const [y, m] = mk.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleString("en-IN", { month: "long", year: "numeric" });
}
function fmtDate(d) {
  return new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
function fmtMoney(n) {
  return "₹" + Number(n || 0).toLocaleString("en-IN");
}
function uid(prefix) {
  return prefix + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function shiftMonth(mk, delta) {
  const [y, m] = mk.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0");
}

export default function App() {
  const [students, setStudents] = useState([]);
  const [attendance, setAttendance] = useState({}); // { date: { studentId: 'present'|'absent' } }
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [tab, setTab] = useState("dashboard");
  const [toast, setToast] = useState(null);

  const showToast = useCallback((msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2600);
  }, []);

  // ---------- load (browser localStorage — persists on this laptop/browser) ----------
  useEffect(() => {
    try {
      const s = localStorage.getItem("dojo-students");
      const a = localStorage.getItem("dojo-attendance");
      const p = localStorage.getItem("dojo-payments");
      if (s) setStudents(JSON.parse(s));
      if (a) setAttendance(JSON.parse(a));
      if (p) setPayments(JSON.parse(p));
    } catch (e) {
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  // ---------- persist helpers ----------
  const saveStudents = useCallback(async (next) => {
    setStudents(next);
    try { localStorage.setItem("dojo-students", JSON.stringify(next)); }
    catch (e) { showToast("Couldn't save student data — try again."); }
  }, [showToast]);

  const saveAttendance = useCallback(async (next) => {
    setAttendance(next);
    try { localStorage.setItem("dojo-attendance", JSON.stringify(next)); }
    catch (e) { showToast("Couldn't save attendance — try again."); }
  }, [showToast]);

  const savePayments = useCallback(async (next) => {
    setPayments(next);
    try { localStorage.setItem("dojo-payments", JSON.stringify(next)); }
    catch (e) { showToast("Couldn't save payment data — try again."); }
  }, [showToast]);

  const resetAll = useCallback(async () => {
    await saveStudents([]);
    await saveAttendance({});
    await savePayments([]);
    showToast("All data cleared.");
  }, [saveStudents, saveAttendance, savePayments, showToast]);

  // ---------- derived ----------
  const attendancePct = useCallback((studentId) => {
    let total = 0, present = 0;
    Object.values(attendance).forEach((day) => {
      if (day[studentId]) {
        total++;
        if (day[studentId] === "present") present++;
      }
    });
    return total ? Math.round((present / total) * 100) : null;
  }, [attendance]);

  const paidForMonth = useCallback((studentId, mk) => {
    return payments
      .filter((p) => p.studentId === studentId && p.month === mk)
      .reduce((sum, p) => sum + p.amount, 0);
  }, [payments]);

  const todayKey = todayISO();
  const presentToday = Object.values(attendance[todayKey] || {}).filter((v) => v === "present").length;

  const currentMonth = monthKey(todayISO());
  const totalDueThisMonth = students.reduce((sum, s) => {
    const paid = paidForMonth(s.id, currentMonth);
    return sum + Math.max(0, s.monthlyFee - paid);
  }, 0);
  const totalCollectedThisMonth = payments
    .filter((p) => p.month === currentMonth)
    .reduce((sum, p) => sum + p.amount, 0);

  if (loading) {
    return (
      <div style={{ ...rootStyle, display: "flex", alignItems: "center", justifyContent: "center", minHeight: 480 }}>
        <Style />
        <div style={{ color: "var(--stone)", fontFamily: "var(--font-body)" }}>Loading dojo records…</div>
      </div>
    );
  }

  return (
    <div style={rootStyle}>
      <Style />
      <div className="dojo-shell">
        <Header />
        <nav className="dojo-tabs">
          {[
            { id: "dashboard", label: "Dashboard", icon: ShieldCheck },
            { id: "students", label: "Students", icon: Users },
            { id: "attendance", label: "Attendance", icon: CalendarCheck },
            { id: "fees", label: "Fees", icon: Wallet },
            { id: "records", label: "Records", icon: FileText },
          ].map((t) => (
            <button
              key={t.id}
              className={"dojo-tab" + (tab === t.id ? " active" : "")}
              onClick={() => setTab(t.id)}
            >
              <t.icon size={16} strokeWidth={2} />
              {t.label}
            </button>
          ))}
        </nav>

        <main className="dojo-main">
          {loadError && (
            <div className="dojo-banner">
              <AlertCircle size={15} /> Couldn't load saved records this session. You can keep working — new changes will still try to save.
            </div>
          )}

          {tab === "dashboard" && (
            <Dashboard
              students={students}
              presentToday={presentToday}
              totalDue={totalDueThisMonth}
              totalCollected={totalCollectedThisMonth}
              currentMonth={currentMonth}
              paidForMonth={paidForMonth}
              attendancePct={attendancePct}
              goTo={setTab}
            />
          )}

          {tab === "students" && (
            <Students
              students={students}
              saveStudents={saveStudents}
              attendancePct={attendancePct}
              paidForMonth={paidForMonth}
              currentMonth={currentMonth}
              payments={payments}
              attendance={attendance}
              showToast={showToast}
            />
          )}

          {tab === "attendance" && (
            <Attendance
              students={students}
              attendance={attendance}
              saveAttendance={saveAttendance}
              showToast={showToast}
            />
          )}

          {tab === "fees" && (
            <Fees
              students={students}
              payments={payments}
              savePayments={savePayments}
              paidForMonth={paidForMonth}
              showToast={showToast}
            />
          )}

          {tab === "records" && (
            <Records
              students={students}
              attendance={attendance}
              payments={payments}
            />
          )}
        </main>

        <footer className="dojo-footer">
          <span>Dojo Manager · records stored on this device</span>
          <button className="dojo-link-btn" onClick={() => {
            if (confirm("Clear every student, attendance and payment record? This cannot be undone.")) resetAll();
          }}>
            <RotateCcw size={13} /> Reset all data
          </button>
        </footer>
      </div>

      {toast && <div className="dojo-toast">{toast}</div>}
    </div>
  );
}

/* ---------------------------------------------------------------
   HEADER
----------------------------------------------------------------*/
function Header() {
  return (
    <header className="dojo-header">
      <img src={logo} alt="MKSF Foundation logo" className="dojo-header-mark" />
      <div>
        <h1 className="dojo-title">MKSF FOUNDATION</h1>
        <p className="dojo-subtitle">Attendance · Fees · Student Records</p>
      </div>
      <div className="dojo-belt-strip" aria-hidden="true">
        {BELTS.map((b) => (
          <span key={b.name} style={{ background: b.color }} className="dojo-belt-seg" />
        ))}
      </div>
    </header>
  );
}

/* ---------------------------------------------------------------
   DASHBOARD
----------------------------------------------------------------*/
function Dashboard({ students, presentToday, totalDue, totalCollected, currentMonth, paidForMonth, attendancePct, goTo }) {
  const overdue = students.filter((s) => paidForMonth(s.id, currentMonth) < s.monthlyFee);

  return (
    <div className="dojo-grid">
      <div className="dojo-stat-row">
        <StatCard label="Students enrolled" value={students.length} icon={Users} onClick={() => goTo("students")} />
        <StatCard label="Present today" value={`${presentToday} / ${students.length}`} icon={CalendarCheck} onClick={() => goTo("attendance")} />
        <StatCard label={`Collected — ${monthLabel(currentMonth)}`} value={fmtMoney(totalCollected)} icon={Wallet} accent="gold" onClick={() => goTo("fees")} />
        <StatCard label="Fees pending" value={fmtMoney(totalDue)} icon={AlertCircle} accent={totalDue > 0 ? "red" : undefined} onClick={() => goTo("fees")} />
      </div>

      <div className="dojo-card">
        <h3 className="dojo-card-title">Pending fees this month</h3>
        {overdue.length === 0 ? (
          <p className="dojo-empty">Every enrolled student is paid up for {monthLabel(currentMonth)}. Nice work.</p>
        ) : (
          <table className="dojo-table">
            <thead><tr><th>Student</th><th>Parent contact</th><th>Due</th></tr></thead>
            <tbody>
              {overdue.map((s) => {
                const due = s.monthlyFee - paidForMonth(s.id, currentMonth);
                return (
                  <tr key={s.id}>
                    <td>{s.name}</td>
                    <td className="dojo-mono">{s.parentPhone}</td>
                    <td className="dojo-mono dojo-amount-due">{fmtMoney(due)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <div className="dojo-card">
        <h3 className="dojo-card-title">Attendance overview</h3>
        {students.length === 0 ? (
          <p className="dojo-empty">Add students to start tracking attendance.</p>
        ) : (
          <div className="dojo-attendance-bars">
            {students.map((s) => {
              const pct = attendancePct(s.id);
              return (
                <div key={s.id} className="dojo-bar-row">
                  <span className="dojo-bar-label">{s.name}</span>
                  <div className="dojo-bar-track">
                    <div className="dojo-bar-fill" style={{ width: `${pct ?? 0}%` }} />
                  </div>
                  <span className="dojo-bar-pct dojo-mono">{pct === null ? "—" : `${pct}%`}</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, accent, onClick }) {
  return (
    <button className={"dojo-stat" + (accent ? ` accent-${accent}` : "")} onClick={onClick}>
      <Icon size={18} strokeWidth={2} />
      <div>
        <div className="dojo-stat-value dojo-mono">{value}</div>
        <div className="dojo-stat-label">{label}</div>
      </div>
    </button>
  );
}

/* ---------------------------------------------------------------
   STUDENTS
----------------------------------------------------------------*/
function Students({ students, saveStudents, attendancePct, paidForMonth, currentMonth, payments, attendance, showToast }) {
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState(null); // student object or null
  const [showForm, setShowForm] = useState(false);
  const [selected, setSelected] = useState(null); // student id for detail view

  const filtered = students.filter((s) => s.name.toLowerCase().includes(query.toLowerCase()));

  function openNew() { setEditing({ id: null, name: "", parentName: "", parentPhone: "", joinDate: todayISO(), monthlyFee: 500, belt: "White" }); setShowForm(true); }
  function openEdit(s) { setEditing({ ...s }); setShowForm(true); }

  async function submitForm(e) {
    e.preventDefault();
    if (!editing.name.trim()) { showToast("Student name is required."); return; }
    if (editing.id) {
      await saveStudents(students.map((s) => (s.id === editing.id ? editing : s)));
      showToast(`Updated ${editing.name}.`);
    } else {
      const newStudent = { ...editing, id: uid("stu") };
      await saveStudents([...students, newStudent]);
      showToast(`${editing.name} added to the roster.`);
    }
    setShowForm(false);
    setEditing(null);
  }

  async function removeStudent(s) {
    if (!confirm(`Remove ${s.name} from the roster? Their attendance and payment history stays on record.`)) return;
    await saveStudents(students.filter((x) => x.id !== s.id));
    showToast(`${s.name} removed.`);
    if (selected === s.id) setSelected(null);
  }

  const detailStudent = students.find((s) => s.id === selected);

  return (
    <div className="dojo-grid">
      <div className="dojo-row-between">
        <div className="dojo-search">
          <Search size={15} />
          <input placeholder="Search students…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <button className="dojo-btn-primary" onClick={openNew}><Plus size={15} /> Add student</button>
      </div>

      <div className="dojo-card">
        {filtered.length === 0 ? (
          <p className="dojo-empty">{students.length === 0 ? "No students yet — add your first student to begin." : "No students match that search."}</p>
        ) : (
          <table className="dojo-table">
            <thead><tr><th>Name</th><th>Belt</th><th>Attendance</th><th>This month</th><th>Parent</th><th></th></tr></thead>
            <tbody>
              {filtered.map((s) => {
                const pct = attendancePct(s.id);
                const due = s.monthlyFee - paidForMonth(s.id, currentMonth);
                return (
                  <tr key={s.id} className="dojo-row-click" onClick={() => setSelected(s.id)}>
                    <td>{s.name}</td>
                    <td><BeltPill name={s.belt} /></td>
                    <td className="dojo-mono">{pct === null ? "—" : `${pct}%`}</td>
                    <td className="dojo-mono">{due > 0 ? <span className="dojo-amount-due">{fmtMoney(due)} due</span> : <span className="dojo-amount-paid">Paid</span>}</td>
                    <td className="dojo-mono">{s.parentPhone}</td>
                    <td className="dojo-row-actions" onClick={(e) => e.stopPropagation()}>
                      <button className="dojo-icon-btn" onClick={() => openEdit(s)}><Pencil size={14} /></button>
                      <button className="dojo-icon-btn" onClick={() => removeStudent(s)}><Trash2 size={14} /></button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {detailStudent && (
        <StudentDetail
          student={detailStudent}
          payments={payments.filter((p) => p.studentId === detailStudent.id)}
          attendance={attendance}
          onClose={() => setSelected(null)}
        />
      )}

      {showForm && (
        <Modal onClose={() => { setShowForm(false); setEditing(null); }} title={editing.id ? "Edit student" : "Add student"}>
          <form onSubmit={submitForm} className="dojo-form">
            <label>Name<input required value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></label>
            <label>Belt<select value={editing.belt} onChange={(e) => setEditing({ ...editing, belt: e.target.value })}>
              {BELTS.map((b) => <option key={b.name} value={b.name}>{b.name}</option>)}
            </select></label>
            <label>Parent name<input value={editing.parentName} onChange={(e) => setEditing({ ...editing, parentName: e.target.value })} /></label>
            <label>Parent phone<input value={editing.parentPhone} onChange={(e) => setEditing({ ...editing, parentPhone: e.target.value })} /></label>
            <label>Join date<input type="date" value={editing.joinDate} onChange={(e) => setEditing({ ...editing, joinDate: e.target.value })} /></label>
            <label>Monthly fee (₹)<input type="number" min="0" value={editing.monthlyFee} onChange={(e) => setEditing({ ...editing, monthlyFee: Number(e.target.value) })} /></label>
            <div className="dojo-form-actions">
              <button type="button" className="dojo-btn-ghost" onClick={() => { setShowForm(false); setEditing(null); }}>Cancel</button>
              <button type="submit" className="dojo-btn-primary">{editing.id ? "Save changes" : "Add student"}</button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

function BeltPill({ name }) {
  const b = BELTS.find((x) => x.name === name) || BELTS[0];
  return <span className="dojo-belt-pill" style={{ background: b.color, color: b.text }}>{name}</span>;
}

function StudentDetail({ student, payments, attendance, onClose }) {
  const months = [];
  for (let i = 5; i >= 0; i--) months.push(shiftMonth(monthKey(todayISO()), -i));
  const dates = Object.keys(attendance).filter((d) => attendance[d][student.id]).sort().reverse().slice(0, 14);

  return (
    <Modal onClose={onClose} title={student.name} wide>
      <div className="dojo-detail">
        <div className="dojo-detail-head">
          <BeltPill name={student.belt} />
          <span className="dojo-mono">{fmtMoney(student.monthlyFee)}/month</span>
          <span className="dojo-detail-parent"><Phone size={13} /> {student.parentName || "—"} · {student.parentPhone || "—"}</span>
        </div>

        <h4 className="dojo-detail-sub">Last 6 months — fee stripe</h4>
        <div className="dojo-fee-stripe">
          {months.map((mk) => {
            const paid = payments.filter((p) => p.month === mk).reduce((s, p) => s + p.amount, 0);
            const ok = paid >= student.monthlyFee;
            return <span key={mk} title={`${monthLabel(mk)}: ${ok ? "Paid" : "Due"}`} className={"dojo-fee-seg" + (ok ? " paid" : " due")} />;
          })}
        </div>

        <h4 className="dojo-detail-sub">Recent attendance</h4>
        {dates.length === 0 ? <p className="dojo-empty">No attendance recorded yet.</p> : (
          <div className="dojo-chip-row">
            {dates.map((d) => (
              <span key={d} className={"dojo-chip" + (attendance[d][student.id] === "present" ? " present" : " absent")}>
                {fmtDate(d)}
              </span>
            ))}
          </div>
        )}

        <h4 className="dojo-detail-sub">Payment history</h4>
        {payments.length === 0 ? <p className="dojo-empty">No payments recorded yet.</p> : (
          <table className="dojo-table">
            <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Receipt</th></tr></thead>
            <tbody>
              {[...payments].sort((a, b) => b.date.localeCompare(a.date)).map((p) => (
                <tr key={p.id}><td>{fmtDate(p.date)}</td><td className="dojo-mono">{fmtMoney(p.amount)}</td><td>{p.method}</td><td className="dojo-mono">{p.receiptNo}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </Modal>
  );
}

/* ---------------------------------------------------------------
   ATTENDANCE
----------------------------------------------------------------*/
function Attendance({ students, attendance, saveAttendance, showToast }) {
  const [date, setDate] = useState(todayISO());
  const dayRecord = attendance[date] || {};

  function setMark(studentId, mark) {
    const next = { ...attendance, [date]: { ...dayRecord, [studentId]: mark } };
    saveAttendance(next);
  }

  function markAll(mark) {
    const next = { ...attendance, [date]: {} };
    students.forEach((s) => { next[date][s.id] = mark; });
    saveAttendance(next);
    showToast(`Marked everyone ${mark} for ${fmtDate(date)}.`);
  }

  const presentCount = Object.values(dayRecord).filter((v) => v === "present").length;

  return (
    <div className="dojo-grid">
      <div className="dojo-row-between">
        <label className="dojo-date-picker">
          Session date
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} max={todayISO()} />
        </label>
        <div className="dojo-row-actions-plain">
          <button className="dojo-btn-ghost" onClick={() => markAll("present")}>Mark all present</button>
          <button className="dojo-btn-ghost" onClick={() => markAll("absent")}>Mark all absent</button>
        </div>
      </div>

      <div className="dojo-card">
        <div className="dojo-card-title-row">
          <h3 className="dojo-card-title">Class of {fmtDate(date)}</h3>
          <span className="dojo-mono dojo-muted">{presentCount} / {students.length} present</span>
        </div>
        {students.length === 0 ? (
          <p className="dojo-empty">Add students first to take attendance.</p>
        ) : (
          <div className="dojo-attend-list">
            {students.map((s) => {
              const mark = dayRecord[s.id];
              return (
                <div key={s.id} className="dojo-attend-row">
                  <span className="dojo-attend-name">{s.name}</span>
                  <BeltPill name={s.belt} />
                  <div className="dojo-attend-toggle">
                    <button className={"dojo-toggle-btn present" + (mark === "present" ? " active" : "")} onClick={() => setMark(s.id, "present")}><Check size={14} /> Present</button>
                    <button className={"dojo-toggle-btn absent" + (mark === "absent" ? " active" : "")} onClick={() => setMark(s.id, "absent")}><X size={14} /> Absent</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   FEES
----------------------------------------------------------------*/
function Fees({ students, payments, savePayments, paidForMonth, showToast }) {
  const [mk, setMk] = useState(monthKey(todayISO()));
  const [payFor, setPayFor] = useState(null); // student
  const [receipt, setReceipt] = useState(null); // payment record to show

  async function recordPayment({ studentId, amount, method, date }) {
    const receiptNo = "RC-" + Date.now().toString(36).toUpperCase().slice(-6);
    const record = { id: uid("pay"), studentId, amount, method, date, month: monthKey(date), receiptNo, recordedAt: new Date().toISOString() };
    await savePayments([...payments, record]);
    setPayFor(null);
    setReceipt(record);
    showToast("Payment recorded.");
  }

  return (
    <div className="dojo-grid">
      <div className="dojo-row-between">
        <div className="dojo-month-nav">
          <button className="dojo-icon-btn" onClick={() => setMk(shiftMonth(mk, -1))}><ChevronLeft size={16} /></button>
          <span className="dojo-mono dojo-month-label">{monthLabel(mk)}</span>
          <button className="dojo-icon-btn" onClick={() => setMk(shiftMonth(mk, 1))}><ChevronRight size={16} /></button>
        </div>
      </div>

      <div className="dojo-card">
        {students.length === 0 ? (
          <p className="dojo-empty">Add students to start tracking fees.</p>
        ) : (
          <table className="dojo-table">
            <thead><tr><th>Student</th><th>Monthly fee</th><th>Paid</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {students.map((s) => {
                const paid = paidForMonth(s.id, mk);
                const due = s.monthlyFee - paid;
                return (
                  <tr key={s.id}>
                    <td>{s.name}</td>
                    <td className="dojo-mono">{fmtMoney(s.monthlyFee)}</td>
                    <td className="dojo-mono">{fmtMoney(paid)}</td>
                    <td>{due <= 0 ? <span className="dojo-amount-paid">Paid</span> : <span className="dojo-amount-due">{fmtMoney(due)} due</span>}</td>
                    <td><button className="dojo-btn-ghost small" onClick={() => setPayFor(s)}>Record payment</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {payFor && (
        <Modal onClose={() => setPayFor(null)} title={`Record payment — ${payFor.name}`}>
          <PaymentForm student={payFor} defaultAmount={Math.max(payFor.monthlyFee - paidForMonth(payFor.id, mk), 0) || payFor.monthlyFee} onSubmit={recordPayment} onCancel={() => setPayFor(null)} />
        </Modal>
      )}

      {receipt && (
        <ReceiptModal
          payment={receipt}
          student={students.find((s) => s.id === receipt.studentId)}
          onClose={() => setReceipt(null)}
        />
      )}
    </div>
  );
}

function PaymentForm({ student, defaultAmount, onSubmit, onCancel }) {
  const [amount, setAmount] = useState(defaultAmount);
  const [method, setMethod] = useState("Cash");
  const [date, setDate] = useState(todayISO());

  return (
    <form className="dojo-form" onSubmit={(e) => { e.preventDefault(); onSubmit({ studentId: student.id, amount: Number(amount), method, date }); }}>
      <label>Amount (₹)<input type="number" min="1" required value={amount} onChange={(e) => setAmount(e.target.value)} /></label>
      <label>Method<select value={method} onChange={(e) => setMethod(e.target.value)}>{METHODS.map((m) => <option key={m}>{m}</option>)}</select></label>
      <label>Date<input type="date" value={date} max={todayISO()} onChange={(e) => setDate(e.target.value)} /></label>
      <div className="dojo-form-actions">
        <button type="button" className="dojo-btn-ghost" onClick={onCancel}>Cancel</button>
        <button type="submit" className="dojo-btn-primary">Confirm payment</button>
      </div>
    </form>
  );
}

function ReceiptModal({ payment, student, onClose }) {
  return (
    <Modal onClose={onClose} title="Payment receipt">
      <div className="dojo-receipt" id="dojo-receipt-print">
        <img src={logo} alt="MKSF Foundation logo" className="dojo-receipt-mark" />
        <h3 className="dojo-receipt-title">MKSF FOUNDATION</h3>
        <p className="dojo-receipt-sub">Fee payment receipt</p>
        <div className="dojo-receipt-rule" />
        <dl className="dojo-receipt-grid">
          <dt>Receipt no.</dt><dd className="dojo-mono">{payment.receiptNo}</dd>
          <dt>Student</dt><dd>{student?.name}</dd>
          <dt>Parent</dt><dd>{student?.parentName || "—"}</dd>
          <dt>Amount</dt><dd className="dojo-mono">{fmtMoney(payment.amount)}</dd>
          <dt>Method</dt><dd>{payment.method}</dd>
          <dt>Date</dt><dd>{fmtDate(payment.date)}</dd>
          <dt>For month</dt><dd>{monthLabel(payment.month)}</dd>
        </dl>
        <div className="dojo-receipt-rule" />
        <div className="dojo-receipt-stamp">
          <ShieldCheck size={16} /> Confirmed by teacher — show this receipt to the parent as proof of payment
        </div>
      </div>
      <div className="dojo-form-actions">
        <button className="dojo-btn-ghost" onClick={onClose}>Close</button>
        <button className="dojo-btn-primary" onClick={() => window.print()}><Printer size={14} /> Print receipt</button>
      </div>
    </Modal>
  );
}

/* ---------------------------------------------------------------
   RECORDS
----------------------------------------------------------------*/
function Records({ students, attendance, payments }) {
  const [view, setView] = useState("attendance");
  const [studentFilter, setStudentFilter] = useState("all");

  const attendanceRows = [];
  Object.keys(attendance).sort().reverse().forEach((date) => {
    Object.entries(attendance[date]).forEach(([studentId, mark]) => {
      if (studentFilter !== "all" && studentId !== studentFilter) return;
      const s = students.find((x) => x.id === studentId);
      attendanceRows.push({ date, name: s ? s.name : "(removed student)", mark });
    });
  });

  const paymentRows = [...payments]
    .filter((p) => studentFilter === "all" || p.studentId === studentFilter)
    .sort((a, b) => b.date.localeCompare(a.date))
    .map((p) => ({ ...p, name: students.find((s) => s.id === p.studentId)?.name || "(removed student)" }));

  return (
    <div className="dojo-grid">
      <div className="dojo-row-between">
        <div className="dojo-tab-mini">
          <button className={"dojo-tab-mini-btn" + (view === "attendance" ? " active" : "")} onClick={() => setView("attendance")}>Attendance log</button>
          <button className={"dojo-tab-mini-btn" + (view === "payments" ? " active" : "")} onClick={() => setView("payments")}>Payment log</button>
        </div>
        <select className="dojo-select" value={studentFilter} onChange={(e) => setStudentFilter(e.target.value)}>
          <option value="all">All students</option>
          {students.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>

      <div className="dojo-card">
        {view === "attendance" ? (
          attendanceRows.length === 0 ? <p className="dojo-empty">No attendance recorded yet.</p> : (
            <table className="dojo-table">
              <thead><tr><th>Date</th><th>Student</th><th>Status</th></tr></thead>
              <tbody>{attendanceRows.map((r, i) => (
                <tr key={i}><td>{fmtDate(r.date)}</td><td>{r.name}</td><td>{r.mark === "present" ? <span className="dojo-amount-paid">Present</span> : <span className="dojo-amount-due">Absent</span>}</td></tr>
              ))}</tbody>
            </table>
          )
        ) : (
          paymentRows.length === 0 ? <p className="dojo-empty">No payments recorded yet.</p> : (
            <table className="dojo-table">
              <thead><tr><th>Date</th><th>Student</th><th>Amount</th><th>Method</th><th>Receipt</th></tr></thead>
              <tbody>{paymentRows.map((p) => (
                <tr key={p.id}><td>{fmtDate(p.date)}</td><td>{p.name}</td><td className="dojo-mono">{fmtMoney(p.amount)}</td><td>{p.method}</td><td className="dojo-mono">{p.receiptNo}</td></tr>
              ))}</tbody>
            </table>
          )
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------
   SHARED — Modal
----------------------------------------------------------------*/
function Modal({ children, onClose, title, wide }) {
  return (
    <div className="dojo-modal-backdrop" onClick={onClose}>
      <div className={"dojo-modal" + (wide ? " wide" : "")} onClick={(e) => e.stopPropagation()}>
        <div className="dojo-modal-head">
          <h3>{title}</h3>
          <button className="dojo-icon-btn" onClick={onClose}><X size={16} /></button>
        </div>
        <div className="dojo-modal-body">{children}</div>
      </div>
    </div>
  );
}

const rootStyle = { minHeight: "100%", fontFamily: "var(--font-body)" };

/* ---------------------------------------------------------------
   STYLE TOKENS
----------------------------------------------------------------*/
function Style() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap');

      .dojo-shell {
        --sumi: #1C1B1A;
        --washi: #F1EAD9;
        --belt-red: #A6352C;
        --indigo: #2E3A4E;
        --gold: #B8912F;
        --stone: #746E64;
        --line: #DDD3BC;
        --paper: #FBF8F1;
        --font-display: 'Oswald', sans-serif;
        --font-body: 'Inter', sans-serif;
        --font-mono: 'JetBrains Mono', monospace;

        background: var(--paper);
        color: var(--sumi);
        border-radius: 14px;
        border: 1px solid var(--line);
        overflow: hidden;
        max-width: 980px;
        margin: 0 auto;
      }

      .dojo-header {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 20px 24px 16px;
        background: var(--sumi);
        color: var(--washi);
        position: relative;
      }
      .dojo-header-mark {
        width: 46px; height: 46px;
        object-fit: cover;
        border-radius: 50%;
        flex-shrink: 0;
        background: #fff;
      }
      .dojo-title {
        font-family: var(--font-display);
        font-size: 20px;
        letter-spacing: 0.06em;
        margin: 0;
        font-weight: 600;
      }
      .dojo-subtitle {
        margin: 2px 0 0;
        font-size: 12.5px;
        color: #C9C0AC;
      }
      .dojo-belt-strip {
        margin-left: auto;
        display: flex;
        height: 8px;
        width: 120px;
        border-radius: 4px;
        overflow: hidden;
        flex-shrink: 0;
      }
      .dojo-belt-seg { flex: 1; }

      .dojo-tabs {
        display: flex;
        gap: 4px;
        padding: 10px 16px;
        background: var(--washi);
        border-bottom: 1px solid var(--line);
        overflow-x: auto;
      }
      .dojo-tab {
        display: flex; align-items: center; gap: 6px;
        padding: 8px 14px;
        border-radius: 8px;
        border: none;
        background: transparent;
        color: var(--stone);
        font-family: var(--font-body);
        font-size: 13.5px;
        font-weight: 500;
        cursor: pointer;
        white-space: nowrap;
      }
      .dojo-tab:hover { background: rgba(28,27,26,0.06); }
      .dojo-tab.active { background: var(--sumi); color: var(--washi); }

      .dojo-main { padding: 20px 24px 8px; min-height: 340px; }
      .dojo-grid { display: flex; flex-direction: column; gap: 16px; }

      .dojo-banner {
        display: flex; align-items: center; gap: 8px;
        background: #FCEFEA; color: var(--belt-red);
        border: 1px solid #EBC9BE; border-radius: 8px;
        padding: 10px 12px; font-size: 13px;
      }

      .dojo-stat-row { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
      @media (max-width: 720px) { .dojo-stat-row { grid-template-columns: repeat(2, 1fr); } }
      .dojo-stat {
        display: flex; align-items: center; gap: 10px;
        background: #fff;
        border: 1px solid var(--line);
        border-radius: 10px;
        padding: 12px 14px;
        cursor: pointer;
        text-align: left;
        color: var(--sumi);
      }
      .dojo-stat:hover { border-color: var(--sumi); }
      .dojo-stat.accent-gold svg { color: var(--gold); }
      .dojo-stat.accent-red svg { color: var(--belt-red); }
      .dojo-stat-value { font-size: 17px; font-weight: 600; }
      .dojo-stat-label { font-size: 11.5px; color: var(--stone); margin-top: 1px; }

      .dojo-card { background: #fff; border: 1px solid var(--line); border-radius: 10px; padding: 16px; }
      .dojo-card-title { font-family: var(--font-display); font-size: 14px; letter-spacing: 0.03em; margin: 0 0 10px; font-weight: 600; }
      .dojo-card-title-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
      .dojo-muted { color: var(--stone); font-size: 12.5px; }

      .dojo-table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
      .dojo-table th { text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--stone); padding: 6px 10px; border-bottom: 1px solid var(--line); }
      .dojo-table td { padding: 9px 10px; border-bottom: 1px solid #EFE9DA; }
      .dojo-row-click { cursor: pointer; }
      .dojo-row-click:hover td { background: #FAF6EC; }
      .dojo-row-actions { display: flex; gap: 4px; }

      .dojo-mono { font-family: var(--font-mono); }
      .dojo-amount-due { color: var(--belt-red); font-weight: 500; }
      .dojo-amount-paid { color: #3E6B4A; font-weight: 500; }
      .dojo-empty { color: var(--stone); font-size: 13.5px; padding: 14px 4px; }

      .dojo-row-between { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; }
      .dojo-row-actions-plain { display: flex; gap: 8px; }

      .dojo-search { display: flex; align-items: center; gap: 6px; border: 1px solid var(--line); border-radius: 8px; padding: 7px 10px; background: #fff; color: var(--stone); flex: 1; max-width: 280px; }
      .dojo-search input { border: none; outline: none; font-size: 13.5px; width: 100%; font-family: var(--font-body); }

      .dojo-btn-primary { display: flex; align-items: center; gap: 6px; background: var(--belt-red); color: #fff; border: none; border-radius: 8px; padding: 9px 14px; font-size: 13.5px; font-weight: 500; cursor: pointer; font-family: var(--font-body); }
      .dojo-btn-primary:hover { background: #8E2E26; }
      .dojo-btn-ghost { background: transparent; border: 1px solid var(--line); border-radius: 8px; padding: 8px 13px; font-size: 13px; cursor: pointer; color: var(--sumi); font-family: var(--font-body); }
      .dojo-btn-ghost:hover { border-color: var(--sumi); }
      .dojo-btn-ghost.small { padding: 5px 10px; font-size: 12.5px; }
      .dojo-icon-btn { background: transparent; border: none; cursor: pointer; color: var(--stone); padding: 5px; border-radius: 6px; display: flex; }
      .dojo-icon-btn:hover { background: #EFE9DA; color: var(--sumi); }
      .dojo-link-btn { background: none; border: none; color: var(--stone); font-size: 12px; display: flex; align-items: center; gap: 5px; cursor: pointer; font-family: var(--font-body); }
      .dojo-link-btn:hover { color: var(--belt-red); }

      .dojo-belt-pill { font-size: 11px; font-weight: 600; padding: 3px 9px; border-radius: 999px; display: inline-block; border: 1px solid rgba(0,0,0,0.08); }

      .dojo-attendance-bars { display: flex; flex-direction: column; gap: 8px; }
      .dojo-bar-row { display: flex; align-items: center; gap: 10px; }
      .dojo-bar-label { width: 140px; font-size: 13px; flex-shrink: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      .dojo-bar-track { flex: 1; height: 7px; background: #EFE9DA; border-radius: 4px; overflow: hidden; }
      .dojo-bar-fill { height: 100%; background: var(--indigo); border-radius: 4px; }
      .dojo-bar-pct { width: 40px; text-align: right; font-size: 12.5px; color: var(--stone); }

      .dojo-form { display: flex; flex-direction: column; gap: 12px; }
      .dojo-form label { display: flex; flex-direction: column; gap: 5px; font-size: 12.5px; color: var(--stone); font-weight: 500; }
      .dojo-form input, .dojo-form select { border: 1px solid var(--line); border-radius: 7px; padding: 8px 10px; font-size: 13.5px; font-family: var(--font-body); color: var(--sumi); }
      .dojo-form-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 6px; }

      .dojo-modal-backdrop { position: fixed; inset: 0; background: rgba(28,27,26,0.5); display: flex; align-items: center; justify-content: center; z-index: 50; padding: 16px; }
      .dojo-modal { background: #fff; border-radius: 12px; width: 420px; max-width: 100%; max-height: 88vh; overflow-y: auto; }
      .dojo-modal.wide { width: 560px; }
      .dojo-modal-head { display: flex; justify-content: space-between; align-items: center; padding: 14px 18px; border-bottom: 1px solid var(--line); }
      .dojo-modal-head h3 { margin: 0; font-family: var(--font-display); font-size: 15px; font-weight: 600; }
      .dojo-modal-body { padding: 18px; }

      .dojo-detail-head { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin-bottom: 14px; }
      .dojo-detail-parent { font-size: 12.5px; color: var(--stone); display: flex; align-items: center; gap: 5px; }
      .dojo-detail-sub { font-family: var(--font-display); font-size: 12px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--stone); margin: 16px 0 8px; }
      .dojo-fee-stripe { display: flex; gap: 4px; }
      .dojo-fee-seg { flex: 1; height: 14px; border-radius: 3px; }
      .dojo-fee-seg.paid { background: var(--gold); }
      .dojo-fee-seg.due { background: #EFE9DA; border: 1px dashed var(--belt-red); }
      .dojo-chip-row { display: flex; flex-wrap: wrap; gap: 6px; }
      .dojo-chip { font-size: 11.5px; padding: 4px 9px; border-radius: 999px; font-family: var(--font-mono); }
      .dojo-chip.present { background: #E7F0E9; color: #3E6B4A; }
      .dojo-chip.absent { background: #FCEFEA; color: var(--belt-red); }

      .dojo-date-picker { display: flex; flex-direction: column; gap: 4px; font-size: 12px; color: var(--stone); font-weight: 500; }
      .dojo-date-picker input { border: 1px solid var(--line); border-radius: 7px; padding: 7px 9px; font-family: var(--font-body); font-size: 13.5px; }

      .dojo-attend-list { display: flex; flex-direction: column; gap: 6px; }
      .dojo-attend-row { display: flex; align-items: center; gap: 12px; padding: 8px 4px; border-bottom: 1px solid #F2EEE2; }
      .dojo-attend-name { flex: 1; font-size: 13.5px; }
      .dojo-attend-toggle { display: flex; gap: 6px; }
      .dojo-toggle-btn { display: flex; align-items: center; gap: 4px; border: 1px solid var(--line); background: #fff; border-radius: 7px; padding: 6px 10px; font-size: 12.5px; cursor: pointer; color: var(--stone); font-family: var(--font-body); }
      .dojo-toggle-btn.present.active { background: #3E6B4A; border-color: #3E6B4A; color: #fff; }
      .dojo-toggle-btn.absent.active { background: var(--belt-red); border-color: var(--belt-red); color: #fff; }

      .dojo-month-nav { display: flex; align-items: center; gap: 10px; }
      .dojo-month-label { font-size: 14px; min-width: 150px; text-align: center; }

      .dojo-tab-mini { display: flex; gap: 4px; background: #EFE9DA; border-radius: 8px; padding: 3px; }
      .dojo-tab-mini-btn { border: none; background: transparent; padding: 6px 12px; border-radius: 6px; font-size: 12.5px; cursor: pointer; color: var(--stone); font-family: var(--font-body); }
      .dojo-tab-mini-btn.active { background: #fff; color: var(--sumi); }
      .dojo-select { border: 1px solid var(--line); border-radius: 7px; padding: 7px 10px; font-size: 12.5px; font-family: var(--font-body); background: #fff; }

      .dojo-receipt { border: 1px dashed var(--line); border-radius: 10px; padding: 20px; text-align: center; background: var(--paper); }
      .dojo-receipt-mark { width: 44px; height: 44px; object-fit: cover; border-radius: 50%; margin: 0 auto 8px; display: block; }
      .dojo-receipt-title { font-family: var(--font-display); font-size: 15px; margin: 0; letter-spacing: 0.05em; }
      .dojo-receipt-sub { font-size: 11.5px; color: var(--stone); margin: 2px 0 0; }
      .dojo-receipt-rule { border-top: 1px dashed var(--line); margin: 14px 0; }
      .dojo-receipt-grid { display: grid; grid-template-columns: auto 1fr; gap: 7px 14px; text-align: left; font-size: 13px; }
      .dojo-receipt-grid dt { color: var(--stone); }
      .dojo-receipt-grid dd { margin: 0; font-weight: 500; }
      .dojo-receipt-stamp { display: flex; align-items: center; gap: 7px; justify-content: center; color: #3E6B4A; font-size: 12px; font-weight: 500; }

      .dojo-footer { display: flex; justify-content: space-between; align-items: center; padding: 12px 24px; border-top: 1px solid var(--line); font-size: 11.5px; color: var(--stone); background: var(--washi); }

      .dojo-toast { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: var(--sumi); color: var(--washi); padding: 10px 18px; border-radius: 999px; font-size: 13px; z-index: 60; }

      @media print {
        .dojo-shell > *:not(.dojo-main), .dojo-modal-head, .dojo-form-actions { display: none !important; }
        .dojo-modal-backdrop { position: static; background: none; }
        .dojo-modal { box-shadow: none; width: 100%; }
      }
    `}</style>
  );
}
